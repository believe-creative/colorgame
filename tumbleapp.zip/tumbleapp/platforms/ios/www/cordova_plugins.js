cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-game-center.GameCenter",
      "file": "plugins/cordova-plugin-game-center/www/gamecenter.js",
      "pluginId": "cordova-plugin-game-center",
      "clobbers": [
        "gamecenter"
      ]
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-whitelist": "1.3.4",
    "cordova-plugin-game-center": "0.4.2"
  };
});