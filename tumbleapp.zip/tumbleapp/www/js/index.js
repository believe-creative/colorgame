/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Wait for the deviceready event before using any of Cordova's device APIs.
// See https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
document.addEventListener("deviceready", onDeviceReady, false);

function listDir(path) {
  return new Promise((resolve, reject) => {
    window.resolveLocalFileSystemURL(
      path,
      function (fileSystem) {
        var reader = fileSystem.createReader();
        reader.readEntries(
          (entries) => {
            for (let i = 0; i < entries.length; i++) {
              if (
                entries[i].isFile == true &&
                entries[i].name.indexOf("bundle.min.js") >= 0
              ) {
                resolve({ has: true });
                break;
              }
            }
            reject({ error: false });
            console.log(entries);
          },
          (err) => {
            reject({ error: err });
            console.log(err);
          }
        );
      },
      function (err) {
        reject({ error: err });
        console.log(err);
      }
    );
  });
}
//example: list of www/audio/ folder in cordova/ionic app.

function callback() {
  setTimeout(()=>{
    console.log("call back...")
    window.dispatchEvent(new Event('resize'));
  },500)
}


function onDeviceReady() {
    var successCallback = function (user) {
        alert(user.alias);
        // user.alias, user.playerID, user.displayName
    };
    
    gamecenter.auth(successCallback, failureCallback);
    
    const script = document.createElement("script");
    script.src = `dist/bundle.min.js`;
    script.async = true;
    script.onload = callback
    document.body.appendChild(script);
 
}
